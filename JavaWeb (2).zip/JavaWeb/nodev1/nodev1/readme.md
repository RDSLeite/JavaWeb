como iniciar um projeto em node:
node index.js

thunder client extensao

  {
    "id": 1,
    "nome": "dev",
    "preco": "5.00"
  }

http://localhost:3000/api/produtos para ver os produtos no new request 

http://localhost:3000/api/produtos/id/ para ver so um ou delete ou put ou post


http://localhost:3000/api/vendas/byemail/Ruizao@oficina.pt isto e no caso das vendas para filtrar email
http://localhost:3000/api/vendas/bypreco/valor1/valor2 isto e no caso do preço 
