// index.js
const express = require('express');
const cors = require('cors');
const app = express();
const produtosRoutes = require('./routes/produtos');
// categorias
const categoriasRoutes = require('./routes/categorias');

app.use(cors());
app.use(express.json());
app.use('/api/produtos', produtosRoutes);
app.use('/api/categorias', categoriasRoutes);

app.get('/', (req, res) => {
  res.send('Olá com Express!');
});

app.listen(3000, () => {
  console.log('API rodando em http://localhost:3000');
});


