como iniciar um projeto em node:
node index.js

thunder client extensao

[
  {
    "id": 1,
    "nome": "dev",
    "preco": "5.00"
  }
]

http://localhost:3000/api/produtos para ver os produtos no new request 

http://localhost:3000/api/produtos/id/ para ver so um ou delete ou put ou post

